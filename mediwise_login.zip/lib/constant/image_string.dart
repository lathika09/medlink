const String SplashAbove='assets/splashabove.png';
const String SplashMiddle='assets/logofin.jpg';
//const String Splashmid='assets/logo name.jpg';
const String Splashbelow='assets/splashbelow.png';
const String wel_img='assets/welcome.jpg';
const String login_pg='assets/login.jpg';
const String bg='assets/bg.jpg';


//appname
const String appname='MediWise';